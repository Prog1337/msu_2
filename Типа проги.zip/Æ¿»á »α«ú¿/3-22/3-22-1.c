#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int regression(double *x, double *y, double *a, double *b, int n)
{
	int i=0;
	double sx=0.0, sy=0.0, sxy=0.0, sxx=0.0;
	for (i=0; i<n; i++)
	{
		sx+=x[i];
		sy+=y[i];
		sxy+=x[i]*y[i];
		sxx+=x[i]*x[i];
	}
	if ( n*sxx-sx*sx>0 )
	{	
		*a=(n*sxy-sx*sy)/(n*sxx-sx*sx);
		*b=(sy-*a*sx)/n;
		printf("a = %le\n", *a);
		printf("b = %le\n", *b);
		printf("Response received\n");
		return 0;
	}
	else 
	{
		printf("Method is not applicable\n");
		return 1;
	}
}

int main(void)
{
	int n=100, i=0;
	printf("The number of variables: %d\n", n);
	double x[n], y[n], a=0.5, b=1, x_min=0.0, dx=10, eps=0.3, err=0.0, errora=0.0, errorb=0.0;
	for(i=0;i<n;i++)
	{
		x[i]=x_min+(dx*rand())/RAND_MAX;
		err=eps*( (2.0*rand()) /RAND_MAX-1.0);
		y[i]=a*x[i]+b+err;
	}
	regression(x, y, &a, &b, n);
	errora=fabs(a-5.e-1);
	errorb=fabs(b-1.);
	printf("Error with the a: %le\nError with the b: %le\n", fabs(a-5.e-1), fabs(b-1.));
	printf("\n");
	a=0.5; b=1; eps=0.6; err=0.0;
	for(i=0;i<n;i++)
	{
		x[i]=x_min+(dx*rand())/RAND_MAX;
		err=eps*( (2.0*rand()) /RAND_MAX-1.0);
		y[i]=a*x[i]+b+err;
	}
	regression(x, y, &a, &b, n);
	printf("Error with the a: %le\nError with the b: %le\n", fabs(a-5.e-1), fabs(b-1.));
	printf("\n");
	printf("Valuation with the a: %le\nValuation with the b: %le\n", fabs(a-5.e-1)/errora, fabs(b-1.)/errorb); 
	return 0;
}
