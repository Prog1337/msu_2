#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int regression(double *x, double *y, double *a, double *b, int n)
{
	int i=0;
	double sx=0.0, sy=0.0, sxy=0.0, sxx=0.0;
	for (i=0; i<n; i++)
	{
		sx+=x[i];
		sy+=y[i];
		sxy+=x[i]*y[i];
		sxx+=x[i]*x[i];
	}
	if ( (n*sxx-sx*sx)>0 )
	{	
		*a=(n*sxy-sx*sy)/(n*sxx-sx*sx);
		*b=(sy-*a*sx)/n;
		printf("a = %le\n", *a);
		printf("b = %le\n", *b);
		printf("Response received\n");
		return 0;
	}
	else 
	{
		printf("Method is not applicable\n");
		return 1;
	}
}

int main(void)
{

	int n=100, i=0;
	printf("The number of variables: %d\n", n);
	double *x, *y, a=0.5, b=1, x_min=0.0, dx=10, eps=0.3, err=0.0;
	x=(double*)malloc(n*sizeof(double));
	y=(double*)malloc(n*sizeof(double));
	for(i=0;i<n;i++)
	{
		x[i]=x_min+(dx*rand())/RAND_MAX;
		err=eps*( (2.0*rand()) /RAND_MAX-1.0);
		y[i]=a*x[i]+b+err;
	}
	regression(x, y, &a, &b, n);
	printf("Error with the a: %le\nError with the b: %le\n", fabs(a-5.e-1), fabs(b-1.e+0));
	return 0;
}
