#include <stdio.h>
#include <stdlib.h>
#include <math.h>

double cubic_spline(double *x, double *f, double *df, double t, int n)
{
	int i=0;
	double l, r;
	for (i=1; i<n-1; i++)
	{
		if (x[i]>=t)
		break;
	}
	l=x[i-1];
	r=x[i];
	return f[i-1] + df[i-1]*(t-l) + ((3*f[i]-3*f[i-1]-df[i]*(r-l)-2*df[i-1]*(r-l))/((r-l)*(r-l)))*(t-l)*(t-l) + ((2*f[i-1]-2*f[i]+df[i]*(r-l)+df[i-1]*(r-l))/((r-l)*(r-l)*(r-l)))*(t-l)*(t-l)*(t-l);
}

int main(void)
{
	int k=0, i=0, j=0;
	printf("The number of nodes: ");
	scanf("%d", &k);
	double *blue, *red, *black, *fblue, *fred, *fblack, *dfblue, *dfred, *dfblack, h=0.0, maximum1=0.0, maximum2=0.0, delta=0.0;
	blue=(double*)malloc((4*k+1)*sizeof(double));
	fblue=(double*)malloc((4*k+1)*sizeof(double));
	dfblue=(double*)malloc((4*k+1)*sizeof(double));
	red=(double*)malloc((2*k+1)*sizeof(double));
	fred=(double*)malloc((2*k+1)*sizeof(double));
	dfred=(double*)malloc((2*k+1)*sizeof(double));
	black=(double*)malloc((k+1)*sizeof(double));
	fblack=(double*)malloc((k+1)*sizeof(double));
	dfblack=(double*)malloc((k+1)*sizeof(double));
	h=M_PI/(2*k);
	for (i=0; i<4*k+1; i++)
	{
		blue[i]=i*h;
		fblue[i]=sin(blue[i]);
		dfblue[i]=cos(blue[i]);
	}
	for (i=0; i<2*k+1; i++)
	{
		red[i]=blue[j];
		fred[i]=sin(red[i]);
		dfred[i]=cos(red[i]);
		j+=2;
	}
	j=0;
	for (i=0; i<k+1; i++)
	{
		black[i]=blue[j];
		fblack[i]=sin(black[i]);
		dfblack[i]=cos(black[i]);
		j+=4;
	}
	maximum1=fabs(cubic_spline(red, fred, dfred, red[0], 2*k+1)-cubic_spline(black, fblack, dfblack, red[0], k+1));
	for (i=1; i<2*k+1; i++)
	{
		delta=fabs(cubic_spline(red, fred, dfred, red[i], 2*k+1)-cubic_spline(black, fblack, dfblack, red[i], k+1));
		if (maximum1<=delta)
		maximum1=delta;
	}
	printf("max1 = %le\n", maximum1);
	maximum2=fabs(cubic_spline(blue, fblue, dfblue, blue[0], 4*k+1)-cubic_spline(red, fred, dfred, blue[0], 2*k+1));
	for (i=1; i<4*k+1; i++)
	{
		delta=fabs(cubic_spline(blue, fblue, dfblue, blue[i], 4*k+1)-cubic_spline(red, fred, dfred, blue[i], 2*k+1));
		if (maximum2<=delta)
		maximum2=delta;
	}
	printf("max2 = %le\n", maximum1);
	printf("Relations : %lf\n", maximum2/maximum1);
	return 0;
}
