#include <stdio.h>
#include <stdlib.h>
#include <math.h>

double cubic_spline(double *x, double *f, double *df, double t, int n)
{
	int i=0;
	double l, r;
	for (i=1; i<n-1; i++)
	{
		if (x[i]>=t)
		break;
	}
	l=x[i-1];
	r=x[i];
	return f[i-1] + df[i-1]*(t-l) + ((3*f[i]-3*f[i-1]-df[i]*(r-l)-2*df[i-1]*(r-l))/((r-l)*(r-l)))*(t-l)*(t-l) + ((2*f[i-1]-2*f[i]+df[i]*(r-l)+df[i-1]*(r-l))/((r-l)*(r-l)*(r-l)))*(t-l)*(t-l)*(t-l);
}

int main(void)
{
	int n=0, i=0;
	printf("The number of nodes: ");
	scanf("%d", &n);
	if (n<=1)
	{
		printf("Error\n");
		return 1;
	}
	double *x, *f, *df, t;
	x=(double*)malloc(n*sizeof(double));
	f=(double*)malloc(n*sizeof(double));
	df=(double*)malloc(n*sizeof(double));
	for (i=0; i<n; i++)
	{
		printf("x[%d] = ", i);
		scanf("%le", &x[i]);
		f[i]=sin(x[i]);
		df[i]=cos(x[i]);
	}
	printf("t = ");
	scanf("%le", &t);
	if (t<x[0] || t>x[n-1])
	{
		printf ("Error\n");
		return 2;
	}
	printf("P2 = %lf", cubic_spline(x, f, df, t, n));
	return 0;
}
