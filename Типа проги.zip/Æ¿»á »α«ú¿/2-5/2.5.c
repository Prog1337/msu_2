#include <stdio.h>
#include <math.h>

double fsin (double y)
{
	int i=1;
	unsigned long long k=0;
	double h, eps=1.e-16, sum=0;
	while( (y-2*M_PI)>=2*k*M_PI )
	{
		k=y/(2*M_PI);
		y=y-2*k*M_PI;
	}
	while( (y+2*M_PI)<=-2*M_PI )
	{
		k=fabs(y/(2*M_PI));
		y=y+2*k*M_PI;
	}
	h=y;
	do
	{
		sum+=h;
		h*=(-1)*y*y/((2*i)*(2*i+1));
		i++;
	} while( fabs(h)>eps );
	return sum;
}

int main(void)
{
	double  x;
	scanf("%le",&x);
	printf("sum=%le\n", fsin(x));
	printf("sin=%le\n", sin(x));
	return 0;
}
