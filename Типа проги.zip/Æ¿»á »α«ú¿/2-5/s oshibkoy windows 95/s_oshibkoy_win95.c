#include <stdio.h>
#include <math.h>

int main(void)
{
	int i=1;
	double  h, eps=1.e-16, x, sum=0;
	scanf("%le",&x);
	h=x;
	do
	{
		sum+=h;
		h*=(-1)*x*x/((2*i)*(2*i+1));
		i++;
	}
	while( fabs(h)>eps );
	printf("sum=%le\nsin=%le\n", sum, sin(x));
	return 0;
}
