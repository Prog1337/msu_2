#include <stdio.h>
#include <math.h>

double foo(double x)
{
    return 8*x*x*x+9*x*x+2*x+2;
}

double Leibniz_Newton(double x)
{
    return 2*x*x*x*x+3*x*x*x+x*x+2*x+3;
}

double integral(double a, double b, int i)
{
    double I = 0.;
    switch (i)
    {
        case 0:
            I = (b-a)*foo(a);
            break;
        case 1:
            I = (b-a)*foo(b);
            break;
        case 2:
            I = ((b-a)*foo((a+b)/2.));
            break;
        case 3:
            I = (b-a)*(foo(a)+foo(b))/2.;
            break;
        case 4:
            I = (b-a)*(foo((a+b)/2-(b-a)/2*sqrt(3))+foo((a+b)/2+(b-a)/2*sqrt(3)))/2.;
            break;
        case 5:
            I = (b-a)*(foo(a)+4*foo((a+b)/2.)+foo(b))/6.;
            break;
        case 6:
            I = (b-a)*(foo(a)+3*foo((2*a+b)/3.)+3*foo((a+2*b)/3.)+foo(b))/8.;
            break;
        case 7:
            I = (b-a)*(foo((a+b)/2.-sqrt(2)*(b-a)/4.)+foo((a+b)/2.)+foo((a+b)/2.+sqrt(2)*(b-a)/4.))/3.;
            break;
        case 8:
			I = (b-a)*(5*foo((a+b)/2.-sqrt(3)/(2*sqrt(5))*(b-a))+8*foo((a+b)/2.)+5*foo((a+b)/2.+sqrt(3)/(2*sqrt(5))*(b-a)))/18.;
			break;
        case 9:
            I = (b-a)*(foo(a)+5*foo((a+b)/2.- (b-a)/(2*sqrt(5)))+5*foo((a+b)/2.+(b-a)/(2*sqrt(5)))+foo(b))/12.;
            break;
        case 10:
            I = (b-a)*(9*foo(a)+49*foo((a+b)/2.-(b-a)*sqrt(3/7)/2.) + 64*foo((a+b)/2.)+49*foo((a+b)/2.+(b-a)*sqrt(3/7)/2.)+9*foo(b))/180.;
        default:
            break;
    }
    return I;
}

int main(void)
{
	double a, b, I, y, d, eps, x = 0.0;
    int i;
    printf("Enter the left bound : ");
    scanf("%lf", &a);
    printf("Enter the right bound : ");
    scanf("%lf", &b);
    I=Leibniz_Newton(b) - Leibniz_Newton(a);
    d = fabs(I) + 1;
    do
    {
        y = I + d;
        eps = y - I;
        d /= 2;
        if (eps>0) x=eps;
    } while (eps>0);
    for (i=0; i<11; i++)
    {
		printf("\n");
		if (i==0)
        printf("Left rectangles\nCalculated value: %le\tExact value: %le\nError: %le\tGrid step: %le\n", integral(a, b, i), I, fabs(I - integral(a, b, i)), x);
        if (i==1)
        printf("Right rectangles\nCalculated value: %le\tExact value: %le\nError: %le\tGrid step: %le\n", integral(a, b, i), I, fabs(I - integral(a, b, i)), x);
        if (i==2)
        printf("Central rectangles\nCalculated value: %le\tExact value: %le\nError: %le\tGrid step: %le\n", integral(a, b, i), I, fabs(I - integral(a, b, i)), x);
        if (i==3)
        printf("Trapezoid\nCalculated value: %le\tExact value: %le\nError: %le\tGrid step: %le\n", integral(a, b, i), I, fabs(I - integral(a, b, i)), x);
        if (i==4)
        printf("Two-point Gauss quadrature\nCalculated value: %le\tExact value: %le\nError: %le\tGrid step: %le\n", integral(a, b, i), I, fabs(I - integral(a, b, i)), x);
        if (i==5)
        printf("Simpson\nCalculated value: %le\tExact value: %le\nError: %le\tGrid step: %le\n", integral(a, b, i), I, fabs(I - integral(a, b, i)), x);
        if (i==6)
        printf("Newton-Cotes\nCalculated value: %le\tExact value: %le\nError: %le\tGrid step: %le\n", integral(a, b, i), I, fabs(I - integral(a, b, i)), x);
        if (i==7)
        printf("Chebyshev\nCalculated value: %le\tExact value: %le\nError: %le\tGrid step: %le\n", integral(a, b, i), I, fabs(I - integral(a, b, i)), x);
        if (i==8)
        printf("Three-point Gauss quadrature\nCalculated value: %le\tExact value: %le\nError: %le\tGrid step: %le\n", integral(a, b, i), I, fabs(I - integral(a, b, i)), x);
        if (i==9)
        printf("Four-point Markov quadrature\nCalculated value: %le\tExact value: %le\nError: %le\tGrid step: %le\n", integral(a, b, i), I, fabs(I - integral(a, b, i)), x);
        if (i==10)
        printf("Five-point Markov quadrature\nCalculated value: %le\tExact value: %le\nError: %le\tGrid step: %le\n", integral(a, b, i), I, fabs(I - integral(a, b, i)), x);
         
    }
    return 0;
}
