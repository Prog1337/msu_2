#include <stdio.h>
#include <stdlib.h>
#include <math.h>

void print_matrix(int n, double **a)
{
    int i=0, j=0;
    for(i=0; i<n; i++)
    {
        for(j=0; j<n; j++)
        printf("%lf\t", a[i][j]);
        printf("\n");
    }    
}

void Gilbert(double **a, int n)
{
    int i=0, j=0;
    for(i=0; i<n; i++)
    for(j=0; j<n; j++)
    a[i][j]=1./(1+i+j);    
}

void Gilbert_identity(double **a, int n)
{
    int i=0, j=0;
    for(i=0; i<n; i++)
    {
        for(j=0; j<n; j++)
        a[i][j]=1./(1+i+j);
        a[i][i]+=1;
    }
}

void Gilbert_without_lower_left_corner(double **a, int n, int k)
{
    int i=0, j=0;
    for(i=0; i<n; i++)
    {
        for(j=0; j<n; j++)
        {
            if(i<j+k)
            a[i][j]=1./(1+i+j);
            else
            a[i][j]=0.0;
        }
    }    
}

void Vandermonde(double **a, double *x, int n)
{
    int i=0, j=0;
    for(i=0; i<n; i++)
    for(j=0; j<n; j++)
    a[i][j]=pow(x[i], j);
}

int main(void)
{
    int n=0, k=0, i=0;
    double **a=NULL, *x=NULL;
    printf("The number of rows and columns of the square matrix : ");
    scanf("%d", &n);
    x=(double*)malloc(n*sizeof(double));
    printf("The angle size less than %d : ", n);
    scanf("%d", &k);
    a=(double**)malloc(n*sizeof(double*));
    for(i=0; i<n; i++)
    a[i]=(double*)malloc(n*sizeof(double));
    Gilbert(a, n);
    printf("\n");
    printf("Gilbert matrix :\n");
    print_matrix(n, a);
    Gilbert_identity(a, n);
    printf("\n");
    printf("Gilbert matrix+identity matrix :\n");
    print_matrix(n, a);
    Gilbert_without_lower_left_corner(a, n, (n-k));
    printf("\n");
    printf("Gilbert matrix without lower-left corner :\n");
    print_matrix(n, a);
    printf("\n");
    for(i=0; i<n; i++)
    {
        printf("x%d : ", i);
        scanf("%le", &x[i]);
    }
    Vandermonde(a, x, n);
    printf("\n");
    printf("Vandermonde matrix :\n");
    print_matrix(n, a);
    return 0;
}
