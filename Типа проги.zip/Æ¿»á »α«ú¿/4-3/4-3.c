#include <stdio.h>
#include <math.h>

double foo(double t)
{
	if (fabs(t)<1.e-15)
	return 0;
	return atan(t)/pow(t, 1./3.);
} 

double integ(double t)
{
	return (12*pow(t, 2./3.)*atan(t)+3*sqrt(3)*log((pow(t, 2./3.)+sqrt(3)*pow(t, 1./3.)+1)/fabs(pow(t, 2./3.)-sqrt(3)*pow(t, 1./3.)+1))-6*(atan(2*pow(t, 1./3.)+sqrt(3))+atan(2*pow(t, 1./3.)-sqrt(3)))-12*atan(pow(t, 1./3.)))/8.;
}

double Markov(double t, double h)
{
	static double c1=0.05, c2=49./180., c3=16./45., k1, k2;
	k1=(1.0-sqrt(3.0/7.0))/2;
	k2=(1.0+sqrt(3.0/7.0))/2;
	return h*(c1*(foo(t)+foo(t+h))+c2*(foo(t+k1*h)+foo(t+k2*h))+c3*foo(t+h/2.));
}

double integral(double alpha, double eps, int *n, double *sum, double *sum_delta, double *sum_delta_abs, double *xmin, double *xmax)
{
	double x=0.0, chi=0.0, h=1./512., hnew=0.0, delta=0.0, delta_abs=0.0, i1=0.0, i2=0.0;
	while(*sum<alpha-eps)
	{
		i1=Markov(x,h); 
        i2=Markov(x,h/2)+Markov(x+h/2,h/2);
		delta=(i2-i1)/255;
		delta_abs=fabs(delta);
		chi=pow(delta_abs/eps, 1.0/9.0);
		if (chi>10.0)
		chi=10.0;
		if (chi<0.1)
		chi=0.1;
		hnew=0.95*h/chi;
		if (delta_abs<eps)
		{
			if (*sum+i2>alpha+eps)
			{
				hnew=h*(alpha-*sum)/i2;
			}
			else 
			{
				x+=h;
				*sum+=i2;
				*sum_delta_abs+=delta_abs;
				(*n)++;
			}
		}
		h=hnew;
	}
	*xmin=(alpha-integ(x)-*sum_delta_abs)/foo(x);
	*xmax=(alpha-integ(x)+*sum_delta_abs)/foo(x);
	return x;
}
		
int main (void)
{
	int n=0;
	double x=0.0, alpha=0.0, xmin=0.0, xmax=0.0, sum=0.0, sum_delta=0.0, sum_delta_abs=0.0;
	printf("Enter the aplha : ");
	scanf("%le", &alpha);
	x=integral(fabs(alpha), 1.e-11, &n, &sum, &sum_delta, &sum_delta_abs, &xmin, &xmax);
	if (alpha<1.e-15)
	x=-x;
	printf("neps=1.e-11: \n");
	printf("The root : %lf\n", x);
	printf("Grid steps : %d\n",n);
	printf("Guaranteeing error : %le\n",sum_delta_abs);
	printf("Exact value : %lf\n",integ(x)-0);
	printf("xmin %le\n",xmin);
	printf("xmax %le\n",xmax);

	return 0;
}
