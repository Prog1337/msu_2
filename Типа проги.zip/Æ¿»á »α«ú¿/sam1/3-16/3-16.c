#include <stdio.h>
#include <math.h>

double foo (double x)
{
	return sin(M_PI*x);
}

double lagr(double *x, double *f, double t, int n)
{
	int i=0, j=0, k=0;
	double l=1, L=0;
	for (i=0; i<n; i++)
	{
		for (k=0; k<n; k++)
		{
			if (j!=k)
			l*=(t-x[k])/(x[j]-x[k]);
		}
		L+=f[i]*l;
		l=1;
		j++;
	}
	return L;
}

int main(void)
{
	int n=3, j=1;
	double x[n], f[n], t=0, delta=0, maximum=0, M=100000;
	x[0]=0;
	x[1]=1./6;
	x[2]=0.5;
	f[0]=foo(x[0]);
	f[1]=foo(x[1]);
	f[2]=foo(x[2]);
	maximum=fabs(lagr(x, f, 0, n)-foo(0));
	for (j=1; j<100000; j++)
	{
		t=(0.5*j)/M;
		delta=fabs(lagr(x, f, t, n)-foo(t));
		if (maximum<=delta)
		maximum=delta;
	}
	printf("Error = %lf\n", maximum);
	return 0;
}
