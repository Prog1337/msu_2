#include <stdio.h>
#include <stdlib.h>
#include <math.h>

void maximum( double* row, int m)
{
	int k;
	double max;
	max=row[0];
	for(k=1;k<m;k++)
	{
		if(fabs(row[k])>max)
		max=fabs(row[k]);
	}
	printf("%le\n",max);
}
void exp_row( double y)
{
	int i=2, j, n=1000;
	double h, eps=1.e-16, *row = malloc(sizeof(*row) * n);
	h=y;
	row[0]=1.0;
	do
	{
		for(j=1;j<n;j++)
		{	
			row[j]=fabs(h);
			h*=y/i;
			i++;
		}
	}while( fabs(h)>eps );
	maximum(row, n);
}

int main(void)
{
	double x;
	scanf("%le",&x);
	exp_row(x);
	return 0;
}
