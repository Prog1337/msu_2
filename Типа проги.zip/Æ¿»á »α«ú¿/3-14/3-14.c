#include <stdio.h>
#include <math.h>

double foo (double x)
{
	return sin(x);
}

double lagr(double *x, double *f, double t, int n)
{
	int i=0, j=0, k=0;
	double l=1, L=0;
	for (i=0; i<n; i++)
	{
		for (k=0; k<n; k++)
		{
			if (j!=k)
			l*=(t-x[k])/(x[j]-x[k]);
		}
		L+=f[i]*l;
		l=1;
		j++;
	}
	return L;
}

int main(void)
{
	int n=0, i=1, j=1;
	printf("Enter the number of nodes\n");
	scanf("%d", &n);
	if (n<=1)
	{
		printf("Error\n");
		return 1;
	}
	double x[n], f[n], t=0, delta=0, maximum=0, M=100000, valuation=1.0, node=1.0;
	x[0]=0;
	f[0]=foo(x[0]);
	for (i=1; i<=n; i++)
	{
		valuation*=0.5/i;
		if (i<n)
		{
			x[i]=node;
			f[i]=foo(x[i]);
			node-=1./(n-1);
			printf("x[%d] = %lf\n", i, x[i]); // отладочная печать
		}
	}
	maximum=fabs(lagr(x, f, 0, n)-foo(0));
	for (j=1; j<100000; j++)
	{
		t=j/M;
		delta=fabs(lagr(x, f, t, n)-foo(t));
		if (maximum<=delta)
		maximum=delta;
	}
	printf("Error = %le\nValuation = %le\n", maximum, valuation);
	return 0;
}
