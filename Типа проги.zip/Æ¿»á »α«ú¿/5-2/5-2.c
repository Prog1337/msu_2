#include <stdio.h>
#include <stdlib.h>
void print_matrix(int n, int m,double **a)
{
    int i=0, j=0;
    for(i=0; i<n; i++)
    {
        for(j=0; j<m; j++)
        printf("%lf\t", a[i][j]);
        printf("\n");
    }    
}
void matrix_addition(double **a, double **b, double **c,int n, int m)
{
    int i=0, j=0;
    for(i=0; i<n; i++)
        for(j=0; j<m; j++)
            c[i][j]=a[i][j]+b[i][j];
}
void matrix_multiplication(double **a, double **b, double **mult, int n, int y)
{
    int i=0, j=0, k=0;
    for(i=0; i<n; i++)
        for(j=0; j<y; j++)
        {
            mult[i][j]=0;
            for(k=0; k<y; k++)            
                mult[i][j]+=a[i][k]*b[k][j];
        }
}
void scalar_multiplication(double **a, double **c, int n, int m, double scalar)
{
    int i=0, j=0;
    for(i=0; i<n; i++)
        for(j=0; j<m; j++)
            c[i][j]=scalar*a[i][j];
}
void vector_multiplying(double **a, double **vector, double **vector_mult, int n, int m)
{
    int i=0, j=0;
    for(i=0; i<n; i++)
    {
        vector_mult[i][0]=0;
        for(j=0; j<m; j++)            
            vector_mult[i][0]+=a[i][j]*vector[j][0];
    }
}
int main(void)
{
    int i=0, j=0, n=0, m=0, x=0, y=0, z=0;
    double **a=NULL, **b=NULL, **c=NULL, **vector=NULL, scalar=0.0;
    printf("Enter the number of rows of the first matrix : ");
    scanf("%d", &n);
    printf("Enter the number of columns of the first matrix: ");
    scanf("%d", &m);
    a=(double**)malloc(n*sizeof(double*));
    for(i=0; i<n; i++)
    {
        a[i]=(double*)malloc(m*sizeof(double));
        for(j=0; j<m; j++)
        {
            printf("a[%d][%d] : ", i, j);
            scanf("%le", &a[i][j]);
        }
    }
    printf("\n");
    printf("Enter the number of rows of the second matrix : ");
    scanf("%d", &x);
    printf("Enter the number of columns of the second matrix: ");
    scanf("%d", &y);
    b=(double**)malloc(x*sizeof(double*));
    for(i=0; i<x; i++)
    {
        b[i]=(double*)malloc(y*sizeof(double));
        for(j=0; j<y; j++)
        {
            printf("b[%d][%d] : ", i, j);
            scanf("%le", &b[i][j]);
        }
    }
    printf("\n");
    printf("Enter the scalar : ");
    scanf("%le", &scalar);
    printf("\n");
    printf("Enter the number of the coordinates of the vector : ");
    scanf("%d", &z);
    vector=(double**)malloc(z*sizeof(double*));
    for(i=0; i<z; i++)
    {
        vector[i]=(double*)malloc(sizeof(double));
        printf("vector[%d][0] : ", i);
        scanf("%le", &vector[i][0]);
    }
    printf("\n");
    if(m==x)
    {
        printf("Multiplying the first matrix by the second matrix :\n");
        c=(double**)malloc(n*sizeof(double*));
        for(i=0; i<n; i++)
            c[i]=(double*)malloc(y*sizeof(double));
        matrix_multiplication(a, b, c, n, y);
        print_matrix(n, y, c);
    }
    else
        printf("The matrices cannot be multiplied.\n");
    printf("\n");
    if(n==x && m==y)
    {
        printf("Adding the first matrix by the second matrix :\n");
        c=(double**)malloc(n*sizeof(double*));
        for(i=0; i<n; i++)
            c[i]=(double*)malloc(m*sizeof(double));
        matrix_addition(a, b, c, n, m);
        print_matrix(n, y, c);
    }
    else
        printf("The matrices cannot be added.\n");
    printf("\n");
    printf("Multiplying the first matrix by the number :\n");
    c=(double**)malloc(n*sizeof(double*));
        for(i=0; i<n; i++)
            c[i]=(double*)malloc(m*sizeof(double));
    scalar_multiplication(a, c, n, m, scalar);
    print_matrix(n, m, c);
    printf("\n");
    printf("Multiplying the second matrix by the number :\n");
    c=(double**)malloc(x*sizeof(double*));
        for(i=0; i<x; i++)
            c[i]=(double*)malloc(y*sizeof(double));
    scalar_multiplication(b, c, x, y, scalar);
    print_matrix(x, y, c);
    printf("\n");
    if(m==z)
    {
        printf("Multiplying the first matrix by the vector :\n");
        c=(double**)malloc(n*sizeof(double*));
        for(i=0; i<n; i++)
            c[i]=(double*)malloc(sizeof(double));
        vector_multiplying(a, vector, c, n, m);
        print_matrix(n, 1, c);
    }
    else
        printf("The first matrix cannot be multiplied by the vector.\n");
    printf("\n");
    if(y==z)
    {
        printf("Multiplying a second matrix by a vector :\n");
        c=(double**)malloc(x*sizeof(double*));
        for(i=0; i<x; i++)
            c[i]=(double*)malloc(sizeof(double));
        vector_multiplying(b, vector, c, x, y);
        print_matrix(x, 1, c);
    }
    else
        printf("The second matrix cannot be multiplied by the vector.\n");
    return 0;
}
