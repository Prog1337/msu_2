#include <stdio.h>
#include <math.h>

double foo (double x)
{
	return sin(x);
}

double lagr(double *x, double *f, double t, int n)
{
	int i=0, j=0, k=0;
	double l=1, L=0; // многочлены; интерполяционный многочлен Лагранжа
	for (i=0; i<n; i++)
	{
		for (k=0; k<n; k++)
		{
			if (j!=k)
			l*=(t-x[k])/(x[j]-x[k]); // сразу считаются значения многочленов в заданной точке
		}
		L+=f[i]*l; // считаетя значение интерполяционного многочлена в заданной точке
		l=1;
		j++;
	}
	return L;
}

int main(void)
{
	int n=0, i=0;
	printf("Enter the number of nodes\n"); // введи число узлов
	scanf("%d", &n);
	if (n<=0)
	{
		printf("Error\n");
		return 1;
	}
	double x[n], f[n], t, L; // массив узлов; массив значений; точка, в которой вычисляется значение интерполяционного многочлена; значение интерполяционного многочлена в заданной точке
	printf("Enter the points\n"); // введи узлы
	for (i=0; i<n; i++)
	{
		scanf("%le", &x[i]);
		f[i]=foo(x[i]);
		printf("f[%d]=%lf\n", i, f[i]);
	}
	printf("Enter the point\n"); // введи точку, в которой вычисляется значение интерполяционного многочлена
	scanf("%le", &t);
	L=lagr (x, f, t, n);
	printf("L = %le\n", L);
	printf("f = %le\n", foo(t)); // печатается правильное значение функции в заданной точке (для видимости прогрешности)
	printf("delta = %le\n", L-foo(t));
	return 0;
}
