#include <stdio.h>
#include <math.h>
int sign(double x);
double shaq(double x);
double my_exp(double x);
int root_half(double a, double b, double (*f)(double), double eps)
{
	double c; int chislo=0;
	if ((sign(f(a))==sign(f(b)))||(sign(f(a))==0)||(sign(f(b))==0)) {printf("Метод не применим\n");return 0;}
	do
	{
		c=(a+b)/2.0;
		if(sign(f(c))==0){printf("Корень: %lf\n",c);break;}
		else
		if(sign(f(a))==sign(f(c))){printf("Корень: %lf\n",c);a=c;}
		else 
		if(sign(f(b))==sign(f(c))) {printf("Корень: %lf\n",c);b=c;}
		chislo++;
		}
while ( (b-a)>=eps);
printf("Количество итераций: %d\n",chislo);
return 0;
}

int sign(double x){
   if(x>0)return 1;
   else
   if(x<0)return -1;
   else if(x==0)return 0;
   return 0;
}

int main(void)
{
   double a,b,f(double),eps=0.01;
   scanf("%le %lf",&a,&b);
   root_half(a,b,&f,eps);
   return 0;
}

double f( double x)
{
    return cos(x);
}
