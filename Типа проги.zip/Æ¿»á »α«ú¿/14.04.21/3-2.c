#include <stdio.h>
#include <math.h>

int sign (double  z)
{
	double e=1.e-15;
	if (z>e)  return 1;
	if (z<-e)  return -1;
	return 0;
}

double f (double y)
{
	return 2*y-(1+y*y)*atan(y+exp(1));
}

int root_half(double *x, double a, double b, double (*f)(double), double eps)
{ 
	int reps=0;
	double c;
	if( sign(f(a)) == 0 )
	{
		*x=a;
		return 1;
	}
	if( sign(f(b)) == 0 )
	{
		*x=b;
		return 1;
	}
	if( sign(f(a)) == sign(f(b)) )
	{
		printf("Method is not applicable\n");
		return 0;
	}
	do
	{
		c=(a+b)/2.;
		if( sign(f(c)) == 0 )
		{
			*x=c;
			break;
		}
		if( sign(f(c)) == sign(f(a)) )
		{
			printf("\n");
			a=c;
			printf("a=%le\tc=%le\nf(a)=%le\tf(c)=%le\n",a , c, f(a), f(c));
		}
		if( sign(f(c)) == sign(f(b)) )
		{
			printf("\n");
			b=c;
			printf("b=%le\tc=%le\nf(b)=%le\tf(c)=%le\n",b , c, f(b), f(c));
		}
		reps++;
	}while ( fabs(b-a)>=eps );
	return reps;
}

int main(void)
{	
	double x, m, n, epsilon=1.e-15;
	int repetitions=0;
	scanf("%le%le", &m, &n);
	repetitions = root_half(&x, m, n, &f, epsilon);
	printf("reps = %d\n", repetitions);
	if( repetitions != 0 )
	printf("root = %le\n", x);
	return 0;
}
