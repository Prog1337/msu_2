#include <stdio.h>
#include <math.h>

int sign (double  z)
{
	double e=1.e-15;
	if (z>e)  return 1;
	if (z<-e)  return -1;
	return 0;
}

double f (double y)
{
	double t;
	t=(y-1)*(y-1)*(y-1);
	return t;
}

int root_half(double *x, double a, double b, double (*f)(double), double eps)
{
	double c;
	int reps=0;
	if( sign(f(a)) == sign(f(b)) )
	{
		printf("Method is not applicable\n");
		return 0;
	}
	do
	{
		c=(a+b)/2.0;
		if( sign(f(c)) == 0 )
		{
			printf("Root = %le\n",c);
			break;
		}
		if(sign(f(a))==sign(f(c)))
		{
			printf("Root = %le\n",c);
			a=c;
		}
		if(sign(f(b))==sign(f(c)))
		{
			printf("Root = %le\n",c);
			b=c;
		}
		reps++;
	}while ( sign(f(c))>=eps);
	printf("Number of repetitions = %d\n",reps);
	return 0;
}

int main(void)
{
	double x, m, n, epsilon=1.e-15;
	int repetitions=0;
	scanf("%le%le", &m, &n);
	repetitions = root_half(&x, m, n, &f, epsilon);
	printf("reps = %d\n", repetitions);
	if( repetitions != 0 )
	printf("root = %le\n", x);
	return 0;
}
