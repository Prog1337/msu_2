#include <stdio.h>
#include <stdlib.h>
#include <math.h>

double foo(double x)
{
	return 1/x;
} 

double Markov(double x, double h)
{
	static double c1=0.05, c2=49./180., c3=16./45., k1, k2;
	k1=(1.0-sqrt(3.0/7.0))/2;
	k2=(1.0+sqrt(3.0/7.0))/2;
	return h*(c1*(foo(x)+foo(x+h))+c2*(foo(x+k1*h)+foo(x+k2*h))+c3*foo(x+h/2.));
}

int integral(double a, double b, double eps, double *sum, double *sum_delta, double *sum_delta_abs)
{
	int n=0;
	double x=a, chi, h=(b-a)/4., delta, delta_abs, i1, i2, hnew;
	*sum=0.;
	*sum_delta=0.;
	*sum_delta_abs=0.;
	while (x<b-eps)
	{
		i1=Markov(x,h); 
        i2=Markov(x,h/2)+Markov(x+h/2,h/2);
		delta=(i2-i1)/255;
		delta_abs=fabs(delta);
		chi=pow(delta_abs/eps, 1.0/9.0);
		if (chi>10.0)
		chi=10.0;
		if (chi<0.1)
		chi=0.1;
		hnew=0.95*h/chi;
		if (delta_abs<eps)
		{
			x+=h;
			*sum+=i2;
			*sum_delta+=delta;
			*sum_delta_abs+=delta_abs;
			n++;
		}
		h=hnew;
		if (x+h>b)
		h=b-x;
	}
	return n;
}
		
int main (void)
{
	int n7, n9, n11;
	double a, b, sum7, sum9, sum11, exact_value, sum_delta7, sum_delta9, sum_delta11, sum_delta_abs7, sum_delta_abs9, sum_delta_abs11;
	printf("Enter the a : ");
	scanf("%le", &a);
	printf("Enter the b : ");
	scanf("%le", &b);
	exact_value=log(b/a);
	printf("\nExact value : %lf\n", exact_value);
	
	printf("\neps=1.e-7: \n");
		n7=integral(a, b, 1.e-7, &sum7, &sum_delta7, &sum_delta_abs7);
	printf("Calculated value :	%lf\n", sum7);
	printf("Number of steps :	%d\n", n7);
	printf("Error :			%le\n", sum7-exact_value);
	printf("Average error :		%le\n", sum_delta7);
	printf("Guaranteeing error :	%le\n", sum_delta_abs7);
	
	printf("\neps=1.e-9: \n");
		n9=integral(a, b, 1.e-9, &sum9, &sum_delta9, &sum_delta_abs9);
	printf("Calculated value :	%lf\n", sum9);
	printf("Number of steps :	%d\n", n9);
	printf("Error :			%le\n", sum9-exact_value);
	printf("Average error :		%le\n", sum_delta9);
	printf("Guaranteeing error :	%le\n", sum_delta_abs9);
	
	printf("\neps=1.e-11: \n");
		n11=integral(a, b, 1.e-11, &sum11, &sum_delta11, &sum_delta_abs11);
	printf("Calculated value :	%lf\n", sum11);
	printf("Number of steps :	%d\n", n11);
	printf("Error :			%le\n", sum11-exact_value);
	printf("Average error :		%le\n", sum_delta11);
	printf("Guaranteeing error :	%le\n", sum_delta_abs11);
	
	printf("\nRatios\n");
	printf("Expected %lf\n", pow(100, 8.0/9.0));
	printf("sum_delta_abs : 7/9 %lf\n", sum_delta_abs7/sum_delta_abs9);
	printf("sum_delta_abs : 9/11 %lf\n", sum_delta_abs9/sum_delta_abs11);
	printf("Exactly 7/9 %lf\n", (sum7-exact_value)/(sum9-exact_value));
	printf("Exactly 9/11 %lf\n", (sum9-exact_value)/(sum11-exact_value));
	printf("(s7-s9)/(s9-s11) : %lf\n", (sum7-sum9)/(sum9-sum11));
	return 0;
}
