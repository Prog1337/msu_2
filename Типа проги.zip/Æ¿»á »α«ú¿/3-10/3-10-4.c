#include <stdio.h>
#include <math.h>

int nf=0;

double f (double x)
{
	nf++;
	return sin(x);
}

int min_half(double *x, double a, double b, double (*f)(double), double eps)
{ 
	int reps=0;
	double x1, x2, x3, t, f1, f2, f3, fx;
	if ( a>b )
	{
		t=a;
		a=b;
		b=t;
	}
	t=b-a;
	fx=f(*x);
	if ( *x<a+t/1024 || *x>b-t/1024 || fx>f(a) || fx>f(b) )
	{
		x1=0.75*a+0.25*b;
		x2=0.5*a+0.5*b;
		x3=0.25*a+0.75*b;
		f1=f(x1);
		f2=f(x2);
		f3=f(x3);
	}
	else if ( *x<a+t/3 )
	{
		x1=*x;
		x2=(2*x1+b)/3;
		x3=(x1+2*b)/3;
		f1=fx;
		f2=f(x2);
		f3=f(x3);
	}
	else if ( *x>b-t/3 )
	{
		x3=*x;
		x1=(2*a+x3)/3;
		x2=(a+2*x3)/3;
		f1=f(x1);
		f2=f(x2);
		f3=fx;
	}
	else
	{
		x2=*x;
		x1=(a+x2)/2;
		x3=(b+x2)/2;
		f1=f(x1);
		f2=fx;
		f3=f(x3);
	}
	printf("f(%lf) = %lf\tf(%lf) = %lf\tf(%lf) = %lf\n", x1, f1, x2, f2, x3, f3);
	for ( reps=0; fabs(b-a)>=eps*fabs(a+b)/2 ; reps++ )
	{
		if ( f1 <= f2 && f1 <= f3 )
		{
			b=x2;
			x2=x1;
			f2=f1; 
		}
		else if ( f2 <= f1 && f2 <= f3 )
		{
			a=x1;
			b=x3;
		}
		else
		{
			a=x2;
			x2=x3;
			f2=f3;
		}
		x1=(a+x2)/2;
		f1=f(x1);
		x3=(x2+b)/2;
		f3=f(x3);
		printf("a = %lf\tb = %lf\nx1 = %lf\tx2 = %lf\tx3 = %lf\nf(%lf) = %lf\n", a, b, x1, x2, x3, *x, f(*x));
	}
	*x=x2;
	return reps;
}

int main(void)
{	
	double x, a, b, epsilon=1.e-30;
	int repetitions=0;
	scanf("%le%le%le", &a, &b, &x);
	repetitions = min_half(&x, a, b, &f, epsilon);
	printf("min = %lf\nreps = %d\nnf=%d\n", x, repetitions, nf);
	return 0;
}

