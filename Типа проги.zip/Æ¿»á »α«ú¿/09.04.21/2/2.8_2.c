#include <stdio.h>
#include <math.h>

int sign(double x)
{
    if (x>0) return 1;
    if (x<0) return -1;
    return 0;
}

int kvadr(double b, double c, double *x1, double *x2)
{
    double d;
    d=b*b-4*c;
    if(d<0) return 0;
    *x1=-(b+sign(b)*sqrt(d))/2;
    *x2=c/(*x1);
    return 1;
}

int main(void) 
{
    double b, c, x1, x2;
    double gor_kat1, gor_kat2;
    scanf("%le%le",&b,&c);
    kvadr(b, c, &x1, &x2);
    printf("x1=%le\tx2=%le\n", x1, x2);
    gor_kat1=fabs((x1*x2+b*x1+c)/(2*x1+b));
    gor_kat2=fabs((x2*x2+b*x2+c)/(2*x2+b));
	printf("%le\t%le\n", gor_kat1, gor_kat2);
    return 0;
}
