#include <stdio.h>

int regression(double *x, double *y, int n)
{
	int i=0;
	double a=0.0, b=0.0, sx=0.0, sy=0.0, sxy=0.0, sxx=0.0;
	for (i=0; i<n; i++)
	{
		sx+=x[i];
		sy+=y[i];
		sxy+=x[i]*y[i];
		sxx+=x[i]*x[i];
	}
	if ( n*sxx-sx*sx>0 )
	{	
		a=(n*sxy-sx*sy)/(n*sxx-sx*sx);
		b=(sy-a*sx)/n;
		printf("a = %le\n", a);
		printf("b = %le\n", b);
		printf("Response received\n");
		return 0;
	}
	else 
	{
		printf("Method is not applicable\n");
		return 1;
	}
}

int main(void)
{
	int n=0, i=0;
	printf("The number of variables: ");
	scanf("%d", &n);
	double x[n], y[n];
	for (i=0; i<n; i++)
	{
		printf("x[%d] = ", i);
		scanf("%le", &x[i]);
	}
	printf("\n");
	for (i=0; i<n; i++)
	{
		printf("y[%d] = ", i);
		scanf("%le", &y[i]);
	}
	printf("\n");
	regression(x, y, n);
	return 0;
}
