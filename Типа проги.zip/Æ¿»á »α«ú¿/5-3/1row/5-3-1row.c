#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>

void Gilbert(double *a, int n)
{
    int i=0, j=0;
    for(i=0; i<n; i++)
		for(j=0; j<n; j++)
			a[i*n+j]=1./(1+i+j);    
}

void Gilbert_identity(double *a, int n)
{
    int i=0, j=0;
    for(i=0; i<n; i++)
    {
        for(j=0; j<n; j++)
			a[i*n+j]=1./(1+i+j);
        a[i*n+i]+=1;
    }
}

void Gilbert_identity_without_lower_left_corner(double *a, int n)
{
    int i=0, j=0;
	for(i=0; i<n; i++)
    {
		for(j=0; j<n; j++)
        {
            if(i<j+501)
				a[i*n+j]=1./(1+j+i);
			else
				a[i*n+j]=0.0;
        }
        a[i*n+i]+=1.;
    }
}

void Gaussian_method(int n, double *a, double *b)
{
	int i=0, j=0, k=0, jmax=0, m=0, *sw=NULL;
	double t=0.0;
	sw=(int*)malloc(n*sizeof(int));
	for(i=0; i<n; i++)
		sw[i]=i;
	for(k=0; k<n; k++)
	{
		jmax=k;
		for(j=k+1; j<n; j++)
			if(fabs(a[k*n+jmax])<fabs(a[k*n+j]))
				jmax=j;
		if(jmax!=k)
		{
			i=sw[k];
			sw[k]=sw[jmax];
			sw[jmax]=i;
			for(i=0; i<n; i++)
			{
				t=a[i*n+k];
				a[i*n+k]=a[i*n+jmax];
				a[i*n+jmax]=t;
			}
		}
		b[k]/=a[k*n+k]; 
		for(j=n-1;j>k;j--)
			a[k*n+j]/=a[k*n+k];
		a[k*n+k]=1.;
		for(i=k+1; i<n; i++)
		{
			b[i]-=b[k]*a[i*n+k];
			for(j=n-1;j>k;j--)
				a[i*n+j]-=a[k*n+j]*a[i*n+k];
			a[i*n+k]=0.;
		}
	}
	for(m=n-1; m>=0; m--)
		for(i=0; i<m; i++)
		{
			b[i]-=b[m]*a[i*n+m];
			a[i*n+m]=0.;
		}
	i=0;
	while(i<n)
	{
		if(sw[i]==i)
			i++;
		else
		{
			j=sw[i];
			t=b[i];
			b[i]=b[j];
			b[j]=t;
			sw[i]=sw[j];
			sw[j]=j;
		}
	}
}

void multiplication(int n, double *a, double *x, double *b)
{
	int i=0, j=0;
	for(i=0; i<n; i++)
	{
		b[i]=0;
		for(j=0; j<n; j++)
			b[i]+=a[i*n+j]*x[j];
	}
}

int main(void)
{
	int i=0, n=0, choice=0;
	double *a=NULL, *b=NULL, *x=NULL, *b0=NULL, v=0.0, error1=0.0, error2=0.0, error3=0.0, t_full=0.0, w=0.0, discrepancy1=0.0, discrepancy2=0.0, discrepancy3=0.0;
	printf("The number of rows and columns of the square matrix : ");
    scanf("%d", &n);
	a=(double*)malloc(n*n*sizeof(double*));
	b=(double*)malloc(n*sizeof(double));
	x=(double*)malloc(n*sizeof(double));
	b0=(double*)malloc(n*sizeof(double));
	for(i=0; i<n; i++)
	{
		if(i%2==0)
			x[i]=1;
		else
			x[i]=-1;
	}
	printf("Which matrix do you want to test?\n1) Gilbert matrix.\n2) Gilbert+E matrix.\n3) Gilbert+E without lower-left corner.\n");
	scanf("%d", &choice);
	switch(choice)
	{
		case (1) :	Gilbert(a, n);
					break;
		case (2) :	Gilbert_identity(a, n);
					break;
		case (3) : 	Gilbert_identity_without_lower_left_corner(a, n);
					break;
		default : 	printf("ERROR!\n");
					return 1;
					break;
	}
	multiplication(n, a, x, b);
	for(i=0; i<n; i++)
		b0[i]=b[i];
	t_full=clock();
	Gaussian_method(n, a, b);
	t_full=clock()-t_full;
	t_full/=CLOCKS_PER_SEC;
	for(i=0; i<n; i++)
	{
		v=fabs(b[i]-x[i]);
		error1+=v;
		error2+=v*v;
		if(v>error3)
			error3=v;
	}
	error1/=n;
	error2=sqrt(error2)/n;
	if(choice==1)
		Gilbert(a,n);
	if(choice==2)
		Gilbert_identity(a, n);
	if(choice==3)
		Gilbert_identity_without_lower_left_corner(a, n);
	multiplication(n, a, b, x);
	for(i=0; i<n; i++)
	{
		w=fabs(x[i]-b0[i]);
		discrepancy1+=w;
		discrepancy2+=w*w;
		if(w>discrepancy3)
			discrepancy3=w;
	}
	discrepancy1/=n;
	discrepancy2=sqrt(discrepancy2)/n;
	printf("The norms of the vector of the error :\n");
	printf("\tThe first norm : %le\n", error1);
	printf("\tThe second norm : %le\n", error2);
	printf("\tThe third norm : %le\n", error3);
	printf("The norms of the discrepancy :\n");
	printf("\tThe first norm : %le\n", discrepancy1);
	printf("\tThe second norm : %le\n", discrepancy2);
	printf("\tThe third norm : %le\n", discrepancy3);
	printf("The total full time : %lf\n", t_full);
	return 0;
}
