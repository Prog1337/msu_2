#include <stdio.h>
#include <math.h>
double norm2(double a[],int n)
{
    int i=0; 
    double sum=0, max, t;
    for (i=0; i<n; i++)
    scanf("%le", &a[i]);
    max=fabs(a[0]);
    for (i=1; i<n; i++)
    if ( max<fabs(a[i]) )
    max=fabs(a[i]);
    for (i=0; i<n; i++)
    {
        t=a[i]/max;
        sum+=t*t;
    }
    return max*sqrt(sum);
}
int main(void)
{
    int m;
    scanf("%d",&m);
    double arr[m];
    printf("%le\n",norm2(arr, m));
    return 0;
}
