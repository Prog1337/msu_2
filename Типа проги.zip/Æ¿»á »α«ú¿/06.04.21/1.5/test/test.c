#include <stdio.h>
int main(void)
{
    long double x,eps=1.0,a;
    scanf("%Le",&x);
    if(x+eps==x)
    {
        while( x+eps==x)
    {
        a=eps;
        eps*=2;
    }}
    else{
    while( x+eps!=x)
    {
        a=eps;
        eps*=0.5;
    }}
    printf("Шаг сетки: %Le",(long double)a);
    return 0;
}
