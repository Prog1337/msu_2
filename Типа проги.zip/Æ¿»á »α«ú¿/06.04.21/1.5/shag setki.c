#include <math.h>
#include <stdio.h>

int main(void) {
    double x, y, d, eps;
    printf("x = ");
    scanf("%le", &x);
    printf("x = %le \n", x);
    d = fabs(x) + 1.0;
    do {
        y = x + d;
        eps = y-x;
        printf("eps = %le\t", eps);
        printf("\n");
        d /= 2;
    } while (eps > 0);
    return 0;
}
