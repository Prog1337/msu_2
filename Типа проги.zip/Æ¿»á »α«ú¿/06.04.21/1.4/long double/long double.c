#include <stdio.h>

int main(void)
{
	long double x=1; int i=0;
	do
	{
		printf("%d: %lg\n",i,(double)x);
		x/=2.0; i--;
		printf("\n");
	}
	while( 1.0+x>1.0 );
	return 0;
}
