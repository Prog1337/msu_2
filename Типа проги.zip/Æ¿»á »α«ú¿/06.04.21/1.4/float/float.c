#include <stdio.h>

int main(void)
{
	float x=1; int i=0;
	do
	{
		printf("%d: %lg\n",i,x);
		x/=2.0; i--;
		printf("\n");
	}
	while( 1+x>1 );
	return 0;
}
