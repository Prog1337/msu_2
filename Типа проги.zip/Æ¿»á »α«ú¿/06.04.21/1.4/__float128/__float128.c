#include <stdio.h>

int main(void)
{
	__float128 x=1.0; int i=0;
	do
	{
		printf("%d: %le\n",i,(double)x);
		x/=2.0; i--;
		printf("\n");
	}
	while( 1.0+x>1.0 );
	return 0;
}
