#include <stdio.h>
#include <math.h>
 
double f(double x)  //функция
{
    return   sin(x)-1/x;
}
 
double f1(double x)    // первая производная функции, f'
{
    return  cos(x)+1/(x*x) ;
}
 
double f2(double x)    //вторая производная функции, f''
{
    return 2/(x*x*x)-sin(x);
}
 
int main()
{
    int n=0;
    double a=1,b=1.5; // отрезок [1,1.5]
    double c, eps=0.0001; // точность
 
    if(f(a)*f2(a)>0)
        c=a;
    else
        c=b;
    do
    {
        c=c-f(c)/f1(c);
        n++;
    }
    while (fabs(f(c))>=eps);  // цикл ищет корень пока его значение больше заданой точности
 
    printf("c=%lf\n",c); //вывод найденого корня
    printf("n=%d\n",n); //вывод количества итераций
    return 0;
}
