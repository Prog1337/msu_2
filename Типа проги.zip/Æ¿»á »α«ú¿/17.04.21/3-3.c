#include <stdio.h>
#include <math.h>

double f (double x)
{
	return (x+1)*x*(x-1);
}

double df (double x)
{
	return 3*x*x-1;
}

int Newton(double *x, double (*f)(double), double (*df)(double), double eps, int n)
{
	int reps=0;
	double x0, h;
	x0=(*x);
	for ( reps=0;  reps<n ; reps++ )
	{
		h=f(x0)/df(x0);
		x0-=h;
		if ( fabs(h)<eps )
		break;
	}
	if ( reps==n )
	return 0;
	*x=x0;
	return reps;
}

int main(void)
{	
	double x, epsilon=1.e-15, t, a=0.44, b=0.58, h;
	int i, m=14000, repetitions=0;
	h=(b-a)/m;
	for ( i=0; i<=m; i++ )
	{
		x=a+i*h;
		t=x;
		repetitions = Newton(&x, f, df, epsilon, 100);
		if ( repetitions )
		{
			if ( fabs(x-1)<1.e-12 )
			printf("%lf -> 1\n", t);
			else if ( fabs(x)<1.e-12 )
			printf("%lf -> 0\n", t);
			else if ( fabs(x+1)<1.e-12 )
			printf("%lf -> -1\n", t);
			else
			{
				printf("Error! t = %lf\t x = %le\n", t, x);
				return 0;
			}
		}
		else
		printf("x = %lf method did not converge\n", x);
	}
	return 0;
}
