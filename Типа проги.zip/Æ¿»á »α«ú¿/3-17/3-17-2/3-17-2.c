#include <stdio.h>
#include <stdlib.h>
#include <math.h>

double linear_spline(double *x, double *f, double t, int k)
{
	int i=0;
	double l=0.0, r=0.0;
	for (i=1; i<k-1; i++)
	{
		if(x[i]>=t)
		break;
	}
	l=x[i-1];
	r=x[i];
	return f[i-1]+(f[i]-f[i-1])*(t-l)/(r-l);
}

int main(void)
{
	int k=0, i=0, j=0;
	scanf("%d", &k);
	double *blue, *red, *black, *fblue, *fred, *fblack, h=0.0, maximum=0.0, delta=0.0; 
	blue=(double*)malloc((4*k+1)*sizeof(double));
	fblue=(double*)malloc((4*k+1)*sizeof(double));
	red=(double*)malloc((2*k+1)*sizeof(double));
	fred=(double*)malloc((2*k+1)*sizeof(double));
	black=(double*)malloc((k+1)*sizeof(double));
	fblack=(double*)malloc((k+1)*sizeof(double));
	h=M_PI/(2*k);
	for (i=0; i<4*k+1; i++)
	{
		blue[i]=i*h;
		fblue[i]=sin(blue[i]);
	}
	for (i=0; i<2*k+1; i++)
	{
		red[i]=blue[j];
		fred[i]=sin(red[i]);
		j+=2;
	}
	j=0;
	for (i=0; i<k+1; i++)
	{
		black[i]=blue[j];
		fblack[i]=sin(black[i]);
		j+=4;
	}
	maximum=fabs(linear_spline(red, fred, red[0], 2*k+1)-linear_spline(black, fblack, red[0], k+1));
	for (i=1; i<2*k+1; i++)
	{
		delta=fabs(linear_spline(red, fred, red[i], 2*k+1)-linear_spline(black, fblack, red[i], k+1));
		if (maximum<=delta)
		maximum=delta;
	}
	printf("max1 = %le\n", maximum);
	maximum=fabs(linear_spline(blue, fblue, blue[0], 4*k+1)-linear_spline(red, fred, blue[0], 2*k+1));
	for (i=1; i<4*k+1; i++)
	{
		delta=fabs(linear_spline(blue, fblue, blue[i], 4*k+1)-linear_spline(red, fred, blue[i], 2*k+1));
		if (maximum<=delta)
		maximum=delta;
	}
	printf("max2 = %le\n", maximum);
	return 0;
}
