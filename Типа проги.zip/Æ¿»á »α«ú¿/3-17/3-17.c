#include <stdio.h>
#include <math.h>

double linear_spline(double *x, double t, int n)
{
	int i=0;
	double l, r, fl, fr, I2;
	for (i=0; i<=n; i++)
	{
		if (x[i+1]>=t)
		{
			l=x[i];
			r=x[i+1];
		}
		if (i==n-1 && x[i]==t)
		{
			l=x[i-1];
			r=x[i];
		}
	}
	fl=sin(l);
	fr=sin(r);
	printf("x[i] = %lf\nx[i+1] = %lf\n", l, r); // отладочная печать
	I2=fl+(fr-fl)*(t-l)/(r-l);
	return I2;
}

int main(void)
{
	int n=0, i=0;
	printf("The number of nodes: ");
	scanf("%d", &n);
	if (n<=1)
	{
		printf("Error\n");
		return 1;
	}
	double x[n], t;
	for (i=0; i<n; i++)
	{
		printf("x[%d] = ", i);
		scanf("%le", &x[i]);
	}
	printf("t = ");
	scanf("%le", &t);
	if (t<x[0] || t>x[n-1])
	{
		printf ("Error\n");
		return 2;
	}
	printf("I2 = %lf", linear_spline(x, t, n));
	return 0;
}
