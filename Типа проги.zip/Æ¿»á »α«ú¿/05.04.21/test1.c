#include <stdio.h>

int main(void)
{
	printf("Size of float=%d\n", (int)sizeof(float));
	printf("Size of double=%d\n", (int)sizeof(double));
	printf("Size of long double=%d\n", (int)sizeof(long double));
	printf("Size of __float128=%d\n", (int)sizeof(__float128));
	return 0;
}

